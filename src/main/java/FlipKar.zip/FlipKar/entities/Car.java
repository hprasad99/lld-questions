package FlipKar.entities;

public class Car extends Vehicle{

    public Car(String type, double pricePerHour) {
        super(type, pricePerHour);
    }
}
