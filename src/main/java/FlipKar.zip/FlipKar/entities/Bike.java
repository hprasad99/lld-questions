package FlipKar.entities;

public class Bike extends Vehicle{

    public Bike(String type, double pricePerHour) {
        super(type, pricePerHour);
    }
}
