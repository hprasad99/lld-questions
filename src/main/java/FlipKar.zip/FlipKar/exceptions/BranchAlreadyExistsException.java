package FlipKar.exceptions;

public class BranchAlreadyExistsException extends Exception {
    public  BranchAlreadyExistsException(String message) {
        super(message);
    }
}
